/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex5;

/**
 *
 * @author jerei
 */
public class Estreno {
    private String titulo;
    private String tipocontenido;
    private double recaudacion;
    private int visualizaciones;
    
    // Cantidad de estrenos por categoría
    private int estrenoactual = 0;
    
    
    
    public Estreno(String unTitulo, String unTipo, double recaudado, int vistas) {
        setTitulo(unTitulo);
        setTipocontenido(unTipo);
        setRecaudacion(recaudado);
        setVisualizaciones(vistas);
    }
    
   
    public String getTitulo() {
        return titulo;
    }

    private void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTipocontenido() {
        return tipocontenido;
    }

    private void setTipocontenido(String tipocontenido) {
        this.tipocontenido = tipocontenido;
    }

    public double getRecaudacion() {
        return recaudacion;
    }

    private void setRecaudacion(double recaudacion) {
        this.recaudacion = recaudacion;
    }

    public int getVisualizaciones() {
        return visualizaciones;
    }

    private void setVisualizaciones(int visualizaciones) {
        this.visualizaciones = visualizaciones;
    }
    
    public String toString() {
        String aux = "Título: " + this.getTitulo() + "\n" +
                     "Tipo de contenido: " + this.getTipocontenido() + "\n" +
                     "Recaudación: " + this.getRecaudacion() + "\n" +
                     "Visualizaciones: " + this.getVisualizaciones();
        return aux;
    }
}

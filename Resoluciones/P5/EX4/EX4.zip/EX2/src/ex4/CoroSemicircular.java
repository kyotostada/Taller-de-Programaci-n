/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4;

/**
 *
 * @author jerei
 */
public class CoroSemicircular extends Coro {
        Corista[] coristas;
        int DimF = 0;
        
        public CoroSemicircular(String unNombre, Director unDirector, int dimf) {
            super(unNombre, unDirector);
            setDimF(dimf);
            coristas = new Corista[dimf];
        }
        
        public void agregarCorista(Corista unCorista) {
            if (!this.estaLleno()) {
                coristas[this.getCantcoristas()] = unCorista;
                this.cantcoristas++;
                
            }
        
        }
        
        private void setDimF(int dimf) {
            this.DimF = dimf;
        }
        
        public int getDimF() {
            return this.DimF;
        }
        
        public String estaBienFormado() {
            int i=0;
            while (i<this.getCantcoristas()) {
                if (coristas[i].getTono() < coristas[i+1].getTono())
                    i++;
            }
            if (i == this.getCantcoristas())
                return "El coro está bien formado";
            else
                return "El coro no está bien formado";
        }
      
        public String toString() {
            String aux = super.toString() + "\n";
            for (int i = 0; i < this.getCantcoristas(); i++) {
                aux+= coristas[i].toString();    
            }
            return aux;
        }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EX1;

/**
 *
 * @author alumnos
 */
public class Investigador {
	private String nombre;
	private int categoria;
	private String especialidad;
	private Subsidio[] subsidios;
	private int cantsubsidios;

	
	
	public Investigador(String nombre, int categoria, String especialidad) {
		setNombre(nombre);
		setCategoria(categoria);
		setEspecialidad(especialidad);
                subsidios = new Subsidio[5];
                
	}

	public void agregarSubsidio(Subsidio subsidio) {
		if (cantsubsidios < 5) {
                    this.subsidios[cantsubsidios] = subsidio;
                    cantsubsidios++;	
		}
	}
	


    public int getCantsubsidios() {
        return cantsubsidios;
    }

    private void setCantsubsidios(int cantsubsidios) {
        this.cantsubsidios = cantsubsidios;
    }
	
        public double calcularMonto() {
            double suma = 0;
            for (int i = 0; i < cantsubsidios; i++) {
                suma+= this.subsidios[i].getMonto();
            }
            return suma;
        }
        
        public void otorgar() {
            for (int i = 0; i < this.getCantsubsidios(); i++) {
                subsidios[i].setFueotorgado(true);
            }
            
            
            
        }
	public String getNombre() {
		return nombre;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCategoria() {
		return categoria;
	}

	private void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	public String getEspecialidad() {
		return especialidad;
	}

	private void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}
	
        @Override
        public String toString() {
            String aux= "Nombre del investigador: " + this.getNombre() + "\n" +
                        "Categoría: " + this.getCategoria() + "\n" +
                        "Dinero total subsidiado: " + this.calcularMonto() + "\n";
            return aux;
                        
        }
        
}

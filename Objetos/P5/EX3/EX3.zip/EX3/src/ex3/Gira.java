/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

/**
 *
 * @author jerei
 */
public class Gira extends Recital {
    private String nombregira;
    private Fecha fechas[];
    private int actual;
    private int cantfechas;
    private int totalFechas;
    
    public Gira(String nombreBanda, int setlist, String nombreGira, int numerodefechas) {
        super(nombreBanda, setlist);
        setTotalFechas(numerodefechas);
        setCantfechas(0);
        setNombregira(nombreGira);
        fechas = new Fecha[numerodefechas];
        for (int i = 0; i < totalFechas; i++) {
            fechas[i] = null;
        setActual(1);
            
        }
    }
    
    public String toString() {
        String aux = super.toString() + "los esperamos en " + fechas[actual - 1].getCiudad();
        actual++;
        return aux;
    }
                
                
    public void agregarFecha(Fecha unaFecha) {
        if (!fechasLlenas()) {
            fechas[this.getCantfechas()] = unaFecha;
            setCantfechas(this.getCantfechas() + 1);
        }
            
    }
    
    public double costoRecital() {
       return (this.getCantfechas() * 30000);
    }
    
    public boolean fechasLlenas() {
        return (this.getCantfechas() == this.getTotalFechas());
    }
    
    public int getTotalFechas() {
        return totalFechas;
    }

    private void setTotalFechas(int totalFechas) {
        this.totalFechas = totalFechas;
    }
    
    
    
    public int getCantfechas() {
        return cantfechas;
    }

    private void setCantfechas(int cantfechas) {
        this.cantfechas = cantfechas;
    }
    
    
    
    public String getNombregira() {
        return nombregira;
    }

    private void setNombregira(String nombregira) {
        this.nombregira = nombregira;
    }

    public int getActual() {
        return actual;
    }

    private void setActual(int actual) {
        this.actual = actual;
    }
    
    
}

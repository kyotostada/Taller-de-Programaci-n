/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4;

/**
 *
 * @author jerei
 */
public abstract class Coro {
    String nombre;
    Director director;
    int cantcoristas = 0;
    int dimf;
    
    
    
    
    public int getCantcoristas() {
        return cantcoristas;
    }

    private void setCantcoristas(int cantcoristas) {
        this.cantcoristas = cantcoristas;
    }
    
    
    
    public Coro(String unNombre, Director unDirector) {
        setNombre(unNombre);
        setDirector(unDirector);
    }

    public Director getDirector() {
        return director;
    }

    private void setDirector(Director director) {
        this.director = director;
    }
    
    public String getNombre() {
        return nombre;
    }

    private void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public boolean estaLleno() {
        return (this.getCantcoristas() == this.getDimF());
    }
    
    public abstract String estaBienFormado();
    public abstract int getDimF();
    
    public abstract void agregarCorista(Corista unCorista);
    
    public String toString() {
        String aux= "Nombre del coro: " + this.getNombre() + "\n" +
                    getDirector().toString();
        return aux;
    }
    
}

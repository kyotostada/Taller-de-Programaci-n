/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex5;

import java.util.HashSet;

/**
 *
 * @author alumnos
 */
public class Subsidio {
	private double monto;
	private String motivo;
	private boolean fueotorgado;
	
	
	
	public Subsidio(double monto, String motivo) {
		setMonto(monto);
		setMotivo(motivo);
                setFueotorgado(false);
		
		
	}

	public boolean isFueotorgado() {
		return fueotorgado;
	}

	public void setFueotorgado(boolean fueotorgado) {
		this.fueotorgado = fueotorgado;
	}
	
	
	public double getMonto() {
		return monto;
	}

	private void setMonto(double monto) {
		this.monto = monto;
	}

	public String getMotivo() {
		return motivo;
	}

	private void setMotivo(String motivo) {
		this.motivo = motivo;
	}
	
	
	
	
	
	
}

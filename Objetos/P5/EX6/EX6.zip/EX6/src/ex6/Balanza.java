/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex6;

/**
 *
 * @author jerei
 */
public class Balanza {
    private int MaxProductos;
    private int numerodecompra;
    private Producto productos[];
    private int cantproductos;
    
    public Balanza() {
        setNumerodecompra(1);
        setMaxProductos(30);
        productos = new Producto[this.getMaxProductos()];
        for (int i = 0; i < this.getMaxProductos(); i++) 
            productos[i] = null;
    }
    
    public void agregarProducto(Producto unProducto) {
        if (!cestoLleno()) {
            productos[this.getCantproductos()] = unProducto;
            setCantproductos(this.getCantproductos() + 1);
        }
    }
    
    public boolean cestoLleno() {
        return (this.getCantproductos() == this.getMaxProductos());
    }
    public int getMaxProductos() {
        return MaxProductos;
    }

    private void setMaxProductos(int MaxProductos) {
        this.MaxProductos = MaxProductos;
    }
    
    public int getNumerodecompra() {
        return numerodecompra;
    }

    private void setNumerodecompra(int numerodecompra) {
        this.numerodecompra = numerodecompra;
    }

    public int getCantproductos() {
        return cantproductos;
    }

    private void setCantproductos(int cantproductos) {
        this.cantproductos = cantproductos;
    }
    
    public void reiniciarBalanza() { 
        setNumerodecompra(this.getNumerodecompra() + 1);
        for (int i = 0; i < this.getMaxProductos(); i++) 
            productos[i] = null;
    }
    
    public double montoTotal() { 
        double suma = 0;
        for(int i = 0; i < this.getCantproductos(); i++) {
            suma+= (productos[i].getPeso() * productos[i].getPreciokg());
        }
        return suma;
    }
    
    public String finalizarCompra() {
        String aux = "Número de compra: " + this.getNumerodecompra() + "\n";
                     for(int i =0; i< this.getCantproductos(); i++)
                         aux += productos[i].toString() + "\n";
                     aux+= "\n" + "Monto total a pagar: " + this.montoTotal();
        return aux;
    }                
}

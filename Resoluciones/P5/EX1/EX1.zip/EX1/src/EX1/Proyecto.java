/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EX1;



/**
 *
 * @author alumnos
 */
public class Proyecto {
	private String nombre;
	private int codigo;
	private String nombredirector;
	private Investigador[] investigadores;
	private int cantinvestigadores = 0;
	
	
	public Proyecto(String nombre, int codigo, String nombredirector) {
		setNombre(nombre);
		setCodigo(codigo);
		setNombreDirector(nombredirector);
                investigadores = new Investigador[50];
	}
	
	
	public void agregarInvestigador(Investigador investigador) {
		if (this.getCantinvestigadores() < 50) {	
			this.investigadores[this.getCantinvestigadores()] = investigador;
			cantinvestigadores++;
		}	
	}
	
	public double dineroTotalOtorgado() {
		double suma = 0;
		for (int i = 0; i < cantinvestigadores; i++) {
			suma += this.investigadores[i].calcularMonto();
		}
		return suma;
	}
			
	public void otorgarTodos(String nombre) {
            int i = 0;
            while (i < this.getCantinvestigadores()) {
                if (investigadores[i].getNombre().equals(nombre))
                    this.investigadores[i].otorgar();
                i++;
            }
        }

        public String getNombredirector() {
            return nombredirector;
        }

        private void setNombredirector(String nombredirector) {
            this.nombredirector = nombredirector;
        }

        public int getCantinvestigadores() {
            return cantinvestigadores;
        }

        private void setCantinvestigadores(int cantinvestigadores) {
            this.cantinvestigadores = cantinvestigadores;
        }
	public String getNombre() {
		return this.nombre;
	}	

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getCodigo() {
		return this.codigo;
	}
	
	public String getNombreDirector() {
		return nombredirector;
	}
	
	private void setNombreDirector(String nombredirector) {
		this.nombredirector = nombredirector;
	}
        
        @Override
        public String toString() {
            String aux= "Nombre del proyecto: " + this.getNombre() + "\n" +
                        "Código: " + this.getCodigo() + "\n" +
                        "Dinero otorgado: " + this.dineroTotalOtorgado() + "\n";
            
            for(int i=0; i<this.cantinvestigadores; i++) 
                aux+= this.investigadores[i].toString();
                         
            return aux;
        }
}








	
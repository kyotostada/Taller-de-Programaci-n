/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4;

/**
 *
 * @author jerei
 */
public class Corista {
    String nombre;
    int dni;
    int edad;
    int tono;

    public String getNombre() {
        return nombre;
    }

    public Corista(String nombre, int dni, int edad, int tono) {
        setNombre(nombre);
        setDni(dni);
        setEdad(edad);
        setTono(tono);
    }
    
    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDni() {
        return dni;
    }

    private void setDni(int dni) {
        this.dni = dni;
    }

    public int getEdad() {
        return edad;
    }

    private void setEdad(int edad) {
        this.edad = edad;
    }

    public int getTono() {
        return tono;
    }

    private void setTono(int tono) {
        this.tono = tono;
    }

    public String toString() {
        String aux= "Nombre del corista: " + this.getNombre() + "\n" +
                    "DNI: " + this.getDni() + "\n" +
                    "Edad: " + this.getEdad() + "\n" +
                    "Tono: " + this.getTono();
        return aux; 
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

/**
 *
 * @author jerei
 */
public class Auto {
    private String nombredueño;
    private String patente;
    
    public Auto(String unNombre, String unaPatente) {
        setNombreDueño(unNombre);
        setPatente(unaPatente);
    }

    public String getNombredueño() {
        return nombredueño;
    }

    private void setNombreDueño(String nombredueño) {
        this.nombredueño = nombredueño;
    }

    public String getPatente() {
        return patente;
    }

    private void setPatente(String patente) {
        this.patente = patente;
    }
    
    public String toString() {
        String aux = "Nombre del dueño: " + this.getNombredueño() + "\n" +
                     "Patente: " + this.getPatente();
        return aux;
    }
    
}

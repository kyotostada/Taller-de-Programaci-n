/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex5;

/**
 *
 * @author alumnos
 */
public class Investigador {
	private String nombre;
	private int categoria;
	private String especialidad;
	private Subsidio[] subsidios;
	private int cantsubsidios;

	
	
	public Investigador(String nombre, int categoria, String especialidad) {
		setNombre(nombre);
		setCategoria(categoria);
		setEspecialidad(especialidad);
                
                
	}

	public void agregarSubsidio(Subsidio subsidio) {
		if (cantsubsidios < 5) {
			this.subsidios[cantsubsidios] = subsidio;
			cantsubsidios++;	
		}
	}
	
	public void otorgarTodos(String nombre) {
		for (int i = 0; i < cantsubsidios; i++) {
                    if (!subsidios[i].isFueotorgado())
                        this.subsidios[i].setFueotorgado(true);
                        
		}
	}
	
        public double calcularMonto() {
            double suma = 0;
            for (int i = 0; i < cantsubsidios; i++) {
                suma+= this.subsidios[i].getMonto();
            }
            return suma;
        }
        
        
	public String getNombre() {
		return nombre;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCategoria() {
		return categoria;
	}

	private void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	public String getEspecialidad() {
		return especialidad;
	}

	private void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}
	
        @Override
        public String toString() {
            String aux= "Nombre del investigador: " + this.getNombre() + "\n" +
                        "Categoría" + this.getCategoria() + "\n" +
                        "Dinero total subsidiado: " + this.calcularMonto();
            return aux;
                        
        }
        
}

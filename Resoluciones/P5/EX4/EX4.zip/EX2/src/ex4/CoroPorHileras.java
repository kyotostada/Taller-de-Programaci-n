/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4;

/**
 *
 * @author jerei
 */
public class CoroPorHileras extends Coro {
    Corista[][] coristas;
        int canthileras;
        int cantintegrantes;
        int hileraactual;
        int integranteactual;
        
    public CoroPorHileras(String unNombre, Director unDirector, int hileras, int integrantes) {
            super(unNombre, unDirector);
            setHileras(hileras);
            setIntegrantes(integrantes);
            this.hileraactual=0;
            this.integranteactual=0;
        }

    public int getIntegranteactual() {
        return integranteactual;
    }

    public int getHileraactual() {
        return hileraactual;
    }

    

    public int getIntegrantes() {
        return cantintegrantes;
    }

    public void setIntegrantes(int integrantes) {
        this.cantintegrantes = integrantes;
    }
    
    
    public void setHileras(int hileras) { 
            this.canthileras = hileras;
    }
    
    public int getHileras() {
        return this.canthileras;
    }
    
    public int getDimF() {
        return this.canthileras + this.cantintegrantes;
    }
    
    public void agregarCorista(Corista unCorista) {
        if (!this.estaLleno())
            coristas[getHileraactual()][getIntegranteactual()] = unCorista;
            this.integranteactual++;
            if (getIntegranteactual() == getIntegrantes()) {
                this.integranteactual = 0;
                this.hileraactual++;
            }
            
            
    }
    
    public String estaBienFormado() {
            int i=0;
            int j=0;
            boolean ok = true;
            while (i<this.getCantcoristas() && ok)  {
                while (i<this.getCantcoristas() && ok) {
                   if (coristas[i][j].getTono() == coristas[i+1][j+1].getTono())
                   j++;
                   else
                       ok = false;
                }
                i++;   
            }
            if (ok)
                return "El coro está bien formado";
            else
                return "El coro no está bien formado";
        }
    
    
    
    
    public String toString() {
        String aux = super.toString() + "\n";
        for(int i = 0; i < this.getHileras(); i++)
            for(int j=0; j< this.getIntegrantes(); j++)
            aux+= coristas[i][j].toString();
        return aux;      
    }
}

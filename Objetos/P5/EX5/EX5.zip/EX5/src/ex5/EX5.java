/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex5;

/**
 *
 * @author jerei
 */
public class EX5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Sistema s = new Sistema("Twitch", 46734256, 5);
       
       
       // cada estreno se guarda el título, el tipo de contenido (serie o película), recaudación
       // obtenida y la cantidad de visualizaciones
       
       s.agregarEstreno(new Estreno("Little Monsters", "Película", 5353453, 43532464), 1);
       s.agregarEstreno(new Estreno("La Leyenda De La Nahuala", "Película", 57435753, 784947), 4);
       s.agregarEstreno(new Estreno("Supernatural", "Serie", 89472396, 129878546), 3);
       
       System.out.println(s.toString());

    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

/**
 *
 * @author jerei
 */
public class Estacionamiento {
    private String nombre;
    private String direccion;
    private int apertura;
    private int cierre;
    private Auto autos[][];
    private int cantpisos;
    private int cantplazas;
    private int cantautos;
    
    
    public Estacionamiento(String unNombre, String unaDirección) {
        setCantpisos(5);
        setCantplazas(10);
        setApertura(8);
        setCierre(21);
        autos = new Auto[cantpisos][cantplazas];
        for (int i = 0; i < cantpisos ; i++) {
            for (int j = 0; j < cantplazas; j++) {
                autos[i][j] = null;
            }
            
        }
        
    }
    
    public Estacionamiento(String unNombre, String unaDirección, int horaApertura, int horaCierre, int pisos, int plazas) {
        setNombre(unNombre);
        setDireccion(unaDirección);
        setApertura(horaApertura);
        setCierre(horaCierre);
        setCantautos(0);
        setCantpisos(pisos);
        setCantplazas(plazas);
        autos = new Auto[pisos][plazas];
        for (int i = 0; i < cantpisos ; i++) {
            for (int j = 0; j < cantplazas; j++) 
                autos[i][j] = null;    
        }
    }
    
    
    public void agregarAuto(Auto A, int pisoX, int plazaY) {
        if (!estaLleno()) {
            autos[pisoX - 1][plazaY - 1] = A;
            cantautos++;
        }
    }
    
    public String buscarAuto (String unaPatente) {
        int i = 0;
        boolean ok = false;
        String aux = "Auto inexistente";
        while (!ok && i < this.getCantpisos()) {
            int j = 0;
            while (!ok && j < this.getCantplazas()) {
                if (autos[i][j].getPatente().equals(unaPatente)) {
                    ok = true;
                    aux = "AUTO ENCONTRADO" + "\n" +
                          "Patente: " + unaPatente + "\n" +
                          "Número de piso: " + (i+1) + "\n" + 
                          "Número de plaza: " + (j+1) + "\n";
                }
                else
                    j++;
            }
            
        }
        return aux;
    }
    
    public String toString() {
        String aux = "";
        for (int i = 0; i < this.getCantpisos(); i++) {
            for (int j = 0; j< this.getCantplazas(); j++) {
                aux += "|" + " Piso " + (i+1) + "Plaza: ";

                if (autos[i][j] != null) 
                    aux+= autos[i][j].toString() + " |";
                else
                    aux+= "Libre" + " |";
            }        
                     
        }
        return aux;    
    }
    
    public int cantAutosEnPlaza (int plazaY) {
        int cant = 0;
        for (int i = 0; i < this.getCantpisos(); i++) {
            if (autos[i][plazaY - 1] != null)
                cant++;
        }
        return cant;
    }
    public boolean estaLleno() {
        return (this.getCantautos() == (this.getCantplazas() * this.getCantpisos()));
    }
    public int getCantautos() {
        return cantautos;
    }

    public int getCantpisos() {
        return cantpisos;
    }

    private void setCantpisos(int cantpisos) {
        this.cantpisos = cantpisos;
    }

    public int getCantplazas() {
        return cantplazas;
    }

    private void setCantplazas(int cantplazas) {
        this.cantplazas = cantplazas;
    }
    
    private void setCantautos(int cantautos) {
        this.cantautos = cantautos;
    }
                  
    public String getNombre() {
        return nombre;
    }

    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    private void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getApertura() {
        return apertura;
    }

    private void setApertura(int apertura) {
        this.apertura = apertura;
    }

    public int getCierre() {
        return cierre;
    }

    private void setCierre(int cierre) {
        this.cierre = cierre;
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

/**
 *
 * @author jerei
 */
public class EventoOcasional extends Recital {
        private String motivo;
        private String nombrecontratante;
        private int diaevento;
    
    public EventoOcasional(String banda, int setlist, String motivo, String unNombre, int unDia) {
        super(banda, setlist);
        setMotivo(motivo);
        setNombrecontratante(unNombre);
        setDiaevento(unDia);
    }    
    
    public String toString() {
        String aux = super.toString() + "\n";
        if (this.getMotivo().equals("A beneficio"))
            aux+= "Recuerden colaborar con " + this.getNombrecontratante();
        else
            if (this.getMotivo().equals("Show de TV"))
                aux+= "Saludos amigos televidentes";
        else
            aux += "Un feliz cumpleaños para " + this.getNombrecontratante();
        return aux;
    }
    
    
    public String getMotivo() {
        return motivo;
    }
    
    public double costoRecital() {
        double costo = -1;
        if (this.getMotivo().equals("A beneficio"))
            costo = 0;
        else
            if (this.getMotivo().equals("Show de TV"))
                costo = 500000;
        else
            costo = 150000;
        return costo;
                
    }
    
    private void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getNombrecontratante() {
        return nombrecontratante;
    }

    private void setNombrecontratante(String nombrecontratante) {
        this.nombrecontratante = nombrecontratante;
    }

    public int getDiaevento() {
        return diaevento;
    }

    private void setDiaevento(int diaevento) {
        this.diaevento = diaevento;
    }
        
        
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

/**
 *
 * @author jerei
 */
import PaqueteLectura.Lector;
public class EX2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estacionamiento e = new Estacionamiento("El estacionamiento de Pepe", "Calle 4, entre 46 y 47", 07, 21, 3, 3);
        
        // Cargamos estacionamiento
        
        for (int i = 0; i < 6; i++) {
            System.out.println("Ingrese el nombre del dueño del auto");
            String dueño = Lector.leerString();
            System.out.println("Ingrese la patente del auto");
            String patente = Lector.leerString();
            System.out.println("Elija piso");
            int piso = Lector.leerInt();
            System.out.println("Elija plaza");
            int plaza = Lector.leerInt();
            e.agregarAuto(new Auto(dueño, patente), piso, plaza);
        }
        // Representación estacionamiento
        System.out.println(e.toString());
        System.out.println();
        
        // Cantidad de autos que están en dicha plaza
        System.out.println("Cantidad de autos en la plaza 1: " + e.cantAutosEnPlaza(1));
        
        // Búsqueda de auto
        
        System.out.println("Ingrese una patente");
        String patente = Lector.leerString();
        System.out.println(e.buscarAuto(patente));
        
        
    
    
    
    }
    
}

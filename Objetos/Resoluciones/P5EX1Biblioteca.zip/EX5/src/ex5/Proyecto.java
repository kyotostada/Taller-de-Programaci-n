/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex5;



/**
 *
 * @author alumnos
 */
public class Proyecto {
	private String nombre;
	private int codigo;
	private String nombredirector;
	private Investigador[] investigadores;
	private int cantinvestigadores;
	
	
	public Proyecto(String nombre, int codigo, String nombredirector) {
		setNombre(nombre);
		setCodigo(codigo);
		setNombreDirector(nombredirector);
	}
	
	
	public void agregarInvestigador(Investigador investigador) {
		if (cantinvestigadores < 50) {	
			this.investigadores[cantinvestigadores] = investigador;
			cantinvestigadores++;
		}	
	}
	
	public double dineroTotalOtorgado() {
		double suma = 0;
		for (int i = 0; i < cantinvestigadores; i++) {
			suma += this.investigadores[i].calcularMonto();
		}
		return suma;
	}
			
	
	public String getNombre() {
		return this.nombre;
	}	

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getCodigo() {
		return this.codigo;
	}
	
	public String getNombreDirector() {
		return nombredirector;
	}
	
	private void setNombreDirector(String nombredirector) {
		this.nombredirector = nombredirector;
	}
        
        @Override
        public String toString() {
            String aux= "Nombre del proyecto: " + this.getNombre() + "\n" +
                        "Código: " + this.getCodigo() + "\n" +
                        "Dinero otorgado: " + this.dineroTotalOtorgado() + "\n";
            
            for(int i=0; i<this.cantinvestigadores; i++) 
                aux+= this.investigadores[i].toString();
                         
            return aux;
        }
}








}	
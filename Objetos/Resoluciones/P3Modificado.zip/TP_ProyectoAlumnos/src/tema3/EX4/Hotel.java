/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3.EX4;

/**
 *
 * @author jerei
 */
public class Hotel {
    private Habitacion habitaciones[];
    
    
    public Hotel(int N, double frente, double contrafrente) {
          habitaciones = new Habitacion[N];
          for (int i = 0; i < N; i++) {
            if (i % 2 == 0)
              habitaciones[i].setCosto(contrafrente);
            else
                habitaciones[i].setCosto(frente);
            
        }
            
        
              
        
        
}

    public Habitacion[] getHabitaciones() {
        return habitaciones;
    }

    public void setHabitaciones(Habitacion[] habitaciones) {
        this.habitaciones = habitaciones;
    }
    
    
    
    
}

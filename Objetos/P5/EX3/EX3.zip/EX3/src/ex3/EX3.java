/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

/**
 *
 * @author jerei
 */
import PaqueteLectura.Lector;
public class EX3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Gira gira = new Gira("Shing02", 6, "Luv(sic) Hexalogy", 5);
        EventoOcasional eo = new EventoOcasional("Aerosmith", 3, "A beneficio", "Warner Bros", 21);
    
    
        // Cargamos gira
        System.out.println("Ingrese setlist");
        for (int i = 0; i < 6; i++) {
            gira.agregarTema(Lector.leerString());
        }
        System.out.println("Ingrese fechas de la gira");
        for (int i = 0; i < 6; i++) {
            System.out.println("Ingrese ciudad");
            String ciudad = Lector.leerString();
            System.out.println("Ingrese día");
            int dia = Lector.leerInt();
            gira.agregarFecha(new Fecha(ciudad, dia));
        }
        
        // Cargamos evento ocasional 
        System.out.println("Ingrese setlist");
        for (int i = 0; i < 3; i++) {
            eo.agregarTema(Lector.leerString());
        }
    
        // Costos de los recitales
        
        System.out.println("Costo de la gira :" +  gira.costoRecital());
        System.out.println("Costo del evento benéfico: " + eo.costoRecital());
        
        // Representación
        
        System.out.println("-------- GIRA -------- ");
        System.out.println(gira.toString());
        System.out.println();
        System.out.println("-------- EVENTO BENÉFICO --------");
        System.out.println(eo.toString());
       
    }
    
}

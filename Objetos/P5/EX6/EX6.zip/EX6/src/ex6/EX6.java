/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex6;

/**
 *
 * @author jerei
 */
import PaqueteLectura.*;
public class EX6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Balanza b = new Balanza();
        BalanzaAvanzada ba = new BalanzaAvanzada();
        
        // Cargamos balanza básica
        System.out.println("Ingrese precio del producto");
        double precio = Lector.leerDouble();
        while (precio != 0) { 
            System.out.println("Ingrese descripción del producto");
            String descripcion = Lector.leerString();
            System.out.println("Ingrese rubro del producto (Fruta o Verdura)");
            String rubro = Lector.leerString();
            System.out.println("Ingrese peso en kilogram");
            double peso = Lector.leerDouble();
            b.agregarProducto(new Producto(descripcion, rubro, precio, peso));
            System.out.println("Ingrese precio del producto");
            precio = Lector.leerDouble();
        }
        
       // Cargamos balanza avanzada
        System.out.println("Ingrese precio del producto");
        precio = Lector.leerDouble();
        while (precio != 0) { 
            System.out.println("Ingrese descripción del producto");
            String descripcion = Lector.leerString();
            System.out.println("Ingrese rubro del producto (Fruta o Verdura)");
            String rubro = Lector.leerString();
            System.out.println("Ingrese peso en kilogram");
            double peso = Lector.leerDouble();
            ba.agregarProducto(new Producto(descripcion, rubro, precio, peso));
            System.out.println("Ingrese precio del producto");
            precio = Lector.leerDouble();
        }
        System.out.println("--------- Balanza básica --------");
        System.out.println(b.finalizarCompra());
        System.out.println("-------- Fin de la compra --------");
        b.reiniciarBalanza();
        System.out.println("-------- Balanza avanzada --------");
        System.out.println(ba.finalizarCompra());
        System.out.println("-------- Fin de la compra --------");
        ba.reiniciarBalanza();
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex6;

/**
 *
 * @author jerei
 */
public class BalanzaAvanzada extends Balanza {
    private int productosverduleria;
    private int productosfruteria;
    
    public BalanzaAvanzada() {
        super();
        setProductosverduleria(0);
        setProductosfruteria(0);
    }

    public int getProductosverduleria() {
        return productosverduleria;
    }

    private void setProductosverduleria(int productosverduleria) {
        this.productosverduleria = productosverduleria;
    }

    public int getProductosfruteria() {
        return productosfruteria;
    }

    private void setProductosfruteria(int productosfruteria) {
        this.productosfruteria = productosfruteria;
    }
    
    public void reiniciarBalanza() {
        super.reiniciarBalanza();
        setProductosverduleria(0);
        setProductosfruteria(0);
    }
    
    public void agregarProducto (Producto unProducto) {
        super.agregarProducto(unProducto);
        if (unProducto.getRubro().equals("Verdura"))
            setProductosverduleria(this.getProductosverduleria() + 1);
        else
            setProductosfruteria(this.getProductosfruteria() + 1);
    }
    
    public String finalizarCompra() {
        String aux = super.finalizarCompra() + "\n" +
                     "Cantidad de frutas: " + this.getProductosfruteria() + "\n" +
                     "Cantidad de verduras: " + this.getProductosverduleria();
        return aux;
    }
}

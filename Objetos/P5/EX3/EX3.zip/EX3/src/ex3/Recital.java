/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

/**
 *
 * @author jerei
 */
public abstract class Recital {
    private String nombrebanda;
    private String temas[];
    private int cantTemas;
    private int totalTemas;
   
    
    public Recital(String banda, int setlist) {
        setCantTemas(0);
        setTotalTemas(setlist);
        setNombrebanda(banda);
        temas = new String[setlist];
        for (int i = 0; i < setlist; i++) {
            temas[i] = null;
            
        }
    }
    
    public String toString() {
        String aux = "Somos " + this.getNombrebanda() + " y tocaremos: " + "\n";
                     for (int i = 0; i < this.getCantTemas(); i++) 
                         aux+= temas[i] + "\n";
        return aux;
    }
    public boolean setlistLleno() { 
        return (this.getCantTemas() == this.getTotalTemas());
    }
    
    public int getCantTemas() {
        return cantTemas;
    }

    public int getTotalTemas() {
        return totalTemas;
    }

    private void setTotalTemas(int totalTemas) {
        this.totalTemas = totalTemas;
    }
    
    private void setCantTemas(int cantTemas) {
        this.cantTemas = cantTemas;
    }
        
    public void agregarTema (String unTema) {
        if (!setlistLleno()) { 
            temas[this.getCantTemas()] = unTema;
            setCantTemas(this.getCantTemas() + 1);
        }
            
    }
    
    public abstract double costoRecital();
    
    public String getNombrebanda() {
        return nombrebanda;
    }

    private void setNombrebanda(String nombrebanda) {
        this.nombrebanda = nombrebanda;
    }
    
    
}

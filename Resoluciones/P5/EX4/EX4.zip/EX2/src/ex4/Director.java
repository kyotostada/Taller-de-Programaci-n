/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4;

/**
 *
 * @author jerei
 */
public class Director {
    String nombre;
    int dni;
    int edad;
    int anti;

    
    public Director(String unNombre, int unDNI, int unaEdad, int unaAnti) {
        setNombre(unNombre);
        setDni(unDNI);
        setEdad(unaEdad);
        setAnti(unaAnti);
    }
    
    
    public String getNombre() {
        return nombre;
    }

    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDni() {
        return dni;
    }

    private void setDni(int dni) {
        this.dni = dni;
    }

    public int getEdad() {
        return edad;
    }

    private void setEdad(int edad) {
        this.edad = edad;
    }

    public int getAnti() {
        return anti;
    }

    private void setAnti(int anti) {
        this.anti = anti;
    }

    public String toString() {
        String aux = "Nombre del director: " + this.getNombre() + "\n" +
                     "DNI: " + this.getDni() + "\n" +
                     "Edad: " + this.getEdad() + "\n" +
                     "Antigüedad: " + this.getAnti() + "\n";
        return aux;
    }

}

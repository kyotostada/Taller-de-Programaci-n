/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex5;

/**
 *
 * @author alumnos
 */
public class Investigador {
	private String nombre;
	private int categoria;
	private String especialidad;
	private Subsidio[] subsidios;
	private int cantsubsidios;

	
	
	public Investigador(String nombre, int categoria, String especialidad) {
		setNombre(nombre);
		setCategoria(categoria);
		setEspecialidad(especialidad);
	}

	public void agregarSubsidio(Subsidio subsidio) {
		if (cantsubsidios < 5) {
			this.subsidios[cantsubsidios] = subsidio;
			cantsubsidios++;	
		}
	}
	
	public void otorgarTodos(String nombre) {
		for (int i = 0; i < cantsubsidios; i++) {
			
		}
	}
	
	public String getNombre() {
		return nombre;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCategoria() {
		return categoria;
	}

	private void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	public String getEspecialidad() {
		return especialidad;
	}

	private void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}
	
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EX1;

/**
 *
 * @author alumnos
 */
public class EX5 {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
            Investigador i1 = new Investigador("Pedro Peralta", 224341, "Hideo Kojima");
            Investigador i2 = new Investigador("Weather Report", 124536, "Hideo Kojima");
            Investigador i3 = new Investigador("Michael Scott", 7443231, "Hideo Kojima");
            
            i1.agregarSubsidio(new Subsidio(124999999, "Compra de alfajores"));
            i1.agregarSubsidio(new Subsidio(10, "Comida"));
            i2.agregarSubsidio(new Subsidio(1232543, "Hospedaje"));
            i2.agregarSubsidio(new Subsidio(234513, "Networking"));
            i3.agregarSubsidio(new Subsidio(5678948, "Sube"));
            i3.agregarSubsidio(new Subsidio(99999.99, "Seguro médico"));
            
            
            
            Proyecto p = new Proyecto("Zomboide", 644312, "Hideo Kojima");
            p.agregarInvestigador(i1);
            p.agregarInvestigador(i2);
            p.agregarInvestigador(i3);
            
            p.otorgarTodos("Pedro Peralta");
            
            System.out.println(p.toString());
            
	}
	
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex5;

/**
 *
 * @author jerei
 */
public class Sistema {
    private String nombreplataforma;
    private int cantsuscriptores;
    private Estreno estrenos[][];
    private int cantporcategoria[];
    private int cantcategorias;
    private int cantmeses=12;
    private int cantestrenos = 0;
    private int mesdisponible = 0;


    public Sistema(String unNombre, int cantSuscriptores, int cantcategorias) {
        setNombre(unNombre);
        setSuscriptores(cantSuscriptores);
        setCantcategorias(cantcategorias);
        cantporcategoria = new int[this.getCantcategorias()];
        estrenos = new Estreno[this.getCantcategorias()][this.getCantmeses()];
        for (int i = 0; i < this.getCantcategorias(); i++) {
            cantporcategoria[i]= 0;
            for(int j = 0; j < this.getCantmeses(); j++)
                estrenos[i][j] = null;    
        }
        
    }
    
    // Se puede hacer con un while buscando posición distinta de null o con un vector contador
    public void agregarEstreno(Estreno unEstreno, int X) {
        if (!this.estaLleno()) {
            estrenos[X-1][cantporcategoria[X-1]] = unEstreno;
            cantestrenos++;
            cantporcategoria[X]++;
        }
    }
    
    public String listadoCategoria(int X) {
        String aux = "Estrenos de la categoria " + X + "\n";
        for (int j = 0; j < this.getCantmeses() ; j++) {
            aux += estrenos[X-1][j].toString();
            
        }
        return aux;
    }
    
    public double recaudacionTotal() {
        double suma = 0;
        for (int i = 0; i < this.getCantcategorias(); i++) {
            for (int j = 0; j < this.getCantmeses(); j++) {
                if (estrenos[i][j] != null)
                    suma+= estrenos[i][j].getRecaudacion();
            }
        }
        return (double) suma/2;
    }
        public int getCantestrenos() {
        return cantestrenos;
    }

    private void setCantestrenos(int cantestrenos) {
        this.cantestrenos = cantestrenos;
    }
    
    public boolean estaLleno() {
        return (this.getCantestrenos() == (this.getCantcategorias() * this.getCantmeses()));
    }

    public int getCantmeses() {
        return cantmeses;
    }

    private void setCantmeses(int cantmeses) {
        this.cantmeses = cantmeses;
    }
    public int getCantcategorias() {
        return cantcategorias;
    }

    private void setCantcategorias(int cantcategorias) {
        this.cantcategorias = cantcategorias;
    }
    
    public String getNombre() {
        return nombreplataforma;
    }

    private void setNombre(String nombreplataforma) {
        this.nombreplataforma = nombreplataforma;
    }

    public int getSuscriptores() {
        return cantsuscriptores;
    }

    private void setSuscriptores(int cantsuscriptores) {
        this.cantsuscriptores = cantsuscriptores;
    }
    
    public String toString() {
        String aux = "Plataforma: " + this.getNombre() + ", Suscriptores: " + this.getSuscriptores() + "\n";
        for (int i = 0; i < this.getCantcategorias(); i++) {
            aux += "\n" + "Categoría" + (i+1) + ":" + "\n";
            for (int j = 0; j < this.getCantmeses(); j++)
                if (estrenos[i][j] != null)
                    aux+= estrenos[i][j].toString();
        }
        aux+= "\n" + "Ganancia total en estrenos: " + this.recaudacionTotal();
        return aux;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex6;

/**
 *
 * @author jerei
 */
public class Producto {
    private String descripcion;
    private String rubro;
    private double peso;
    private double preciokg;
    
    
    public Producto(String unaDescripcion, String unRubro, double unPeso, double unPrecio) {
        setDescripcion(unaDescripcion);
        setRubro(unRubro);
        setPeso(unPeso);
        setPreciokg(unPrecio); 
    }

    public String getDescripcion() {
        return descripcion;
    }

    private void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getRubro() {
        return rubro;
    }

    private void setRubro(String rubro) {
        this.rubro = rubro;
    }

    public double getPeso() {
        return peso;
    }

    private void setPeso(double peso) {
        this.peso = peso;
    }

    public double getPreciokg() {
        return preciokg;
    }

    public void setPreciokg(double preciokg) {
        this.preciokg = preciokg;
    }
    
    public String toString() {
        String aux = "Descripción del producto: " + this.getDescripcion() + "\n" +
                     "Precio final: " + (this.getPeso() * this.getPreciokg());
        return aux;
    }
}

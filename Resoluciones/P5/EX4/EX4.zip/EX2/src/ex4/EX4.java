/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4;

/**
 *
 * @author jerei
 */
import PaqueteLectura.*;
public class EX4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        Director d1 = new Director("Hans Zimmer", 64, 324532, 30);
        Director d2 = new Director("Rubén Doblas", 33, 24152624, 1);
       

        
        // Cargamos coro semicircular

        int n = Lector.leerInt();
        
        CoroSemicircular csc = new CoroSemicircular("Coro de Ensenada", d1, n);
        for(int i = 0; i < n; i++) {
           System.out.println("Ingrese un nombre");
           String nombre = Lector.leerString();
            System.out.println("Ingrese una edad");
           int edad = Lector.leerInt();
            System.out.println("Ingrese un DNI");
           int dni = Lector.leerInt();
            System.out.println("Ingrese un tono fundamental");
           int tono = Lector.leerInt();
           csc.agregarCorista(new Corista(nombre, edad, dni, tono));  
        }
        
        System.out.println(csc.toString());
    
        // Cargamos coro por hileras
        int m = Lector.leerInt();
        n = Lector.leerInt();
        
        CoroPorHileras cph = new CoroPorHileras("Coro de Zacatecas", d2, n, m);
        for (int i = 0; i < n; n++) {
            for (int j=0; j< m; j++) {
                System.out.println("Ingrese un nombre");
                String nombre = Lector.leerString();
                System.out.println("Ingrese una edad");
                int edad = Lector.leerInt();
                System.out.println("Ingrese un DNI");
                int dni = Lector.leerInt();
                System.out.println("Ingrese un tono fundamental");
                int tono = Lector.leerInt();
                cph.agregarCorista(new Corista(nombre, edad, dni, tono)); 
            }
        
            System.out.println(cph.toString());
        
        
        
        
        }
    }   
}
